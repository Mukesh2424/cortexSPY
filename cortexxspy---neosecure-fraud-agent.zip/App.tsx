import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, FunctionDeclaration, Type } from '@google/genai';
import { INITIAL_CASE_DATA, SYSTEM_INSTRUCTION } from './constants';
import { CaseData } from './types';
import { AudioVisualizer } from './components/AudioVisualizer';
import { DatabaseView } from './components/DatabaseView';
import { ConversationLog, Message } from './components/ConversationLog';
import { createPCMBlob, base64ToBytes, decodeAudioData } from './utils/audioUtils';

// --- Configuration ---
const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';

// Define the tool for updating the database
const updateCaseDatabaseFunction: FunctionDeclaration = {
  name: 'updateCaseDatabase',
  parameters: {
    type: Type.OBJECT,
    description: 'Updates the fraud case status and outcome note in the bank database.',
    properties: {
      status: {
        type: Type.STRING,
        description: 'The new status of the case.',
        enum: ['pending_review', 'verification_failed', 'confirmed_safe', 'confirmed_fraud']
      },
      outcomeNote: {
        type: Type.STRING,
        description: 'A brief note explaining the outcome.',
      },
    },
    required: ['status', 'outcomeNote'],
  },
};

const App: React.FC = () => {
  // --- State ---
  const [isConnected, setIsConnected] = useState(false);
  const [isTalking, setIsTalking] = useState(false); // Model is talking
  const [caseData, setCaseData] = useState<CaseData>(INITIAL_CASE_DATA);
  const [error, setError] = useState<string | null>(null);

  // Transcription State
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [currentOutput, setCurrentOutput] = useState('');

  // --- Refs for Audio & Session ---
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const streamRef = useRef<MediaStream | null>(null);

  // Refs for transcription buffering to avoid closure staleness
  const currentInputRef = useRef('');
  const currentOutputRef = useRef('');

  // --- Helpers ---
  
  const stopAudioPlayback = useCallback(() => {
    sourcesRef.current.forEach(source => {
      try { source.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    setIsTalking(false);
  }, []);

  const disconnect = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }
    stopAudioPlayback();
    setIsConnected(false);
    // Reset data for next run
    setCaseData(INITIAL_CASE_DATA);
    setMessages([]);
    setCurrentInput('');
    setCurrentOutput('');
    currentInputRef.current = '';
    currentOutputRef.current = '';
  }, [stopAudioPlayback]);

  const startSession = async () => {
    setError(null);
    if (!process.env.API_KEY) {
      setError("Missing API_KEY in environment");
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // 1. Setup Audio Contexts
      const InputContextClass = (window.AudioContext || (window as any).webkitAudioContext);
      const inputCtx = new InputContextClass({ sampleRate: 16000 });
      const outputCtx = new InputContextClass({ sampleRate: 24000 });
      
      inputAudioContextRef.current = inputCtx;
      outputAudioContextRef.current = outputCtx;
      nextStartTimeRef.current = outputCtx.currentTime;

      // 2. Get Mic Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // 3. Connect to Gemini Live
      const sessionPromise = ai.live.connect({
        model: MODEL_NAME,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          tools: [{ functionDeclarations: [updateCaseDatabaseFunction] }],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log("Session Opened");
            setIsConnected(true);
            
            // Start Audio Input Streaming
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPCMBlob(inputData);
              
              if (sessionPromiseRef.current) {
                sessionPromiseRef.current.then(session => {
                   session.sendRealtimeInput({ media: pcmBlob });
                });
              }
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Tool Calls (Database Updates)
            if (message.toolCall) {
              for (const fc of message.toolCall.functionCalls) {
                 if (fc.name === 'updateCaseDatabase') {
                   const { status, outcomeNote } = fc.args as any;
                   
                   setCaseData(prev => ({
                     ...prev,
                     status,
                     outcomeNote
                   }));

                   sessionPromiseRef.current?.then(session => {
                     session.sendToolResponse({
                       functionResponses: {
                         id: fc.id,
                         name: fc.name,
                         response: { result: 'Database updated successfully' }
                       }
                     });
                   });
                 }
              }
            }

            // Handle Transcriptions
            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              currentOutputRef.current += text;
              setCurrentOutput(currentOutputRef.current);
            }
            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              currentInputRef.current += text;
              setCurrentInput(currentInputRef.current);
            }

            if (message.serverContent?.turnComplete) {
              // Commit the complete turn to history
              const newMessages: Message[] = [];
              if (currentInputRef.current) {
                newMessages.push({ role: 'user', text: currentInputRef.current });
                currentInputRef.current = '';
                setCurrentInput('');
              }
              if (currentOutputRef.current) {
                newMessages.push({ role: 'model', text: currentOutputRef.current });
                currentOutputRef.current = '';
                setCurrentOutput('');
              }
              
              if (newMessages.length > 0) {
                setMessages(prev => [...prev, ...newMessages]);
              }
            }

            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
               setIsTalking(true);
               const ctx = outputAudioContextRef.current;
               
               nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);

               const audioBuffer = await decodeAudioData(
                 base64ToBytes(base64Audio),
                 ctx
               );

               const source = ctx.createBufferSource();
               source.buffer = audioBuffer;
               source.connect(ctx.destination);
               
               source.start(nextStartTimeRef.current);
               nextStartTimeRef.current += audioBuffer.duration;
               
               sourcesRef.current.add(source);
               source.onended = () => {
                 sourcesRef.current.delete(source);
                 if (sourcesRef.current.size === 0) {
                   setIsTalking(false);
                 }
               };
            }

            // Handle Interruption
            if (message.serverContent?.interrupted) {
              stopAudioPlayback();
              // If interrupted, commit what we have so far
              const newMessages: Message[] = [];
              if (currentOutputRef.current) {
                newMessages.push({ role: 'model', text: currentOutputRef.current });
                currentOutputRef.current = '';
                setCurrentOutput('');
              }
              if (newMessages.length > 0) {
                setMessages(prev => [...prev, ...newMessages]);
              }
            }
          },
          onclose: () => {
            console.log("Session Closed");
            setIsConnected(false);
          },
          onerror: (err) => {
            console.error("Session Error", err);
            setError("Connection error occurred. Please restart.");
            disconnect();
          }
        }
      });

      sessionPromiseRef.current = sessionPromise;

    } catch (e: any) {
      console.error(e);
      setError(e.message || "Failed to start session");
    }
  };

  useEffect(() => {
    return () => disconnect();
  }, [disconnect]);

  return (
    <div className="min-h-screen bg-bank-900 flex flex-col p-4 lg:p-8 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-bank-accent/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[40%] h-[40%] bg-bank-alert/5 rounded-full blur-[100px]" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-bank-700 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-bank-700 to-transparent" />
      </div>

      <div className="w-full max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 z-10 relative flex-1">
        
        {/* Left Column: Database & Status (3 cols) */}
        <div className="lg:col-span-3 h-[400px] lg:h-auto">
          <DatabaseView data={caseData} />
        </div>

        {/* Middle Column: Conversation Log (5 cols) */}
        <div className="lg:col-span-5 h-[500px] lg:h-auto">
          <ConversationLog 
            messages={messages} 
            currentInput={currentInput}
            currentOutput={currentOutput}
          />
        </div>

        {/* Right Column: Interaction Hub (4 cols) */}
        <div className="lg:col-span-4 flex flex-col items-center justify-center relative bg-bank-800/50 backdrop-blur-sm border border-bank-700 rounded-lg p-8 shadow-2xl h-auto">
          
          {/* Header */}
          <div className="absolute top-6 left-6 flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-bank-accent animate-ping" />
             <span className="font-mono text-bank-accent text-sm tracking-widest">CORTEX-X SPY</span>
          </div>

          <div className="absolute top-6 right-6">
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border ${isConnected ? 'bg-bank-success/10 text-bank-success border-bank-success/30' : 'bg-bank-700 text-gray-400 border-bank-600'}`}>
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-bank-success' : 'bg-gray-500'}`} />
              {isConnected ? 'ACTIVE' : 'OFFLINE'}
            </div>
          </div>

          {/* Visualizer Centerpiece */}
          <div className="w-full aspect-square max-w-[300px] my-8 relative flex items-center justify-center">
            {isConnected ? (
              <AudioVisualizer isActive={isTalking} barColor={caseData.status === 'confirmed_fraud' ? '#ef4444' : '#3b82f6'} />
            ) : (
              <div className="w-32 h-32 rounded-full border-2 border-dashed border-bank-700 flex items-center justify-center">
                <span className="text-4xl text-bank-700">❖</span>
              </div>
            )}
            
            {/* Status Text Overlay */}
            <div className="absolute -bottom-8 text-center w-full">
              {isConnected && (
                <p className="text-gray-400 text-sm font-mono animate-pulse">
                  {isTalking ? "AGENT SPEAKING..." : "LISTENING..."}
                </p>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="mt-4 w-full flex flex-col items-center gap-4">
            {error && (
              <div className="w-full bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded text-sm text-center mb-2">
                {error}
              </div>
            )}
            
            {!isConnected ? (
              <button 
                onClick={startSession}
                className="group relative w-full py-4 bg-bank-accent hover:bg-blue-600 text-white font-bold rounded overflow-hidden transition-all duration-300 shadow-[0_0_20px_rgba(59,130,246,0.3)] hover:shadow-[0_0_30px_rgba(59,130,246,0.5)]"
              >
                <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                <span className="flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                  CONNECT AGENT
                </span>
              </button>
            ) : (
              <button 
                onClick={disconnect}
                className="w-full py-4 bg-bank-alert/10 hover:bg-bank-alert/20 border border-bank-alert/50 text-bank-alert font-bold rounded transition-all"
              >
                TERMINATE SESSION
              </button>
            )}
            
            <p className="text-xs text-gray-600 max-w-xs text-center">
              Audio processed in real-time via Gemini API.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default App;