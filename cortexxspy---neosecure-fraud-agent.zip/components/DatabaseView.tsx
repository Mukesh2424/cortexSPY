import React from 'react';
import { CaseData } from '../types';

interface Props {
  data: CaseData;
}

export const DatabaseView: React.FC<Props> = ({ data }) => {
  const getStatusColor = (status: CaseData['status']) => {
    switch (status) {
      case 'pending_review': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'confirmed_safe': return 'bg-bank-success/20 text-bank-success border-bank-success/30';
      case 'confirmed_fraud': return 'bg-bank-alert/20 text-bank-alert border-bank-alert/30';
      case 'verification_failed': return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
      default: return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    }
  };

  return (
    <div className="bg-bank-800 border border-bank-700 rounded-lg p-6 font-mono text-sm shadow-xl h-full flex flex-col">
      <div className="flex items-center justify-between mb-4 pb-4 border-b border-bank-700">
        <h2 className="text-bank-accent font-bold text-lg flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
          </svg>
          NEOSECURE DB
        </h2>
        <span className="text-xs text-gray-500">LIVE CONNECTION</span>
      </div>

      <div className="space-y-4 overflow-y-auto flex-1 custom-scrollbar">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-gray-500 block text-xs mb-1">USER NAME</span>
            <div className="text-white">{data.userName}</div>
          </div>
          <div>
            <span className="text-gray-500 block text-xs mb-1">SEC ID</span>
            <div className="text-white">{data.securityIdentifier}</div>
          </div>
        </div>

        <div className="bg-bank-900/50 p-3 rounded border border-bank-700">
          <span className="text-gray-500 block text-xs mb-2">TRANSACTION</span>
          <div className="flex justify-between items-center mb-1">
             <span className="text-white font-bold">{data.merchant}</span>
             <span className="text-white font-bold">{data.amount}</span>
          </div>
          <div className="text-gray-400 text-xs">{data.transactionTime}</div>
          <div className="text-gray-400 text-xs">{data.location}</div>
        </div>

        <div>
          <span className="text-gray-500 block text-xs mb-1">CASE STATUS</span>
          <div className={`px-3 py-1.5 rounded border inline-block ${getStatusColor(data.status)} uppercase font-bold text-xs tracking-wider`}>
            {data.status.replace('_', ' ')}
          </div>
        </div>

        {data.outcomeNote && (
          <div className="animate-pulse bg-white/5 p-3 rounded border border-white/10">
            <span className="text-gray-500 block text-xs mb-1">OUTCOME NOTE</span>
            <div className="text-gray-300 italic">"{data.outcomeNote}"</div>
          </div>
        )}
      </div>

      <div className="mt-4 pt-4 border-t border-bank-700 text-xs text-gray-600">
        SECURE CONNECTION // ENCRYPTED // FAKE DATA ONLY
      </div>
    </div>
  );
};
