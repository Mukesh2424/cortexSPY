import React, { useEffect, useRef } from 'react';

export interface Message {
  role: 'user' | 'model';
  text: string;
}

interface Props {
  messages: Message[];
  currentInput: string;
  currentOutput: string;
}

export const ConversationLog: React.FC<Props> = ({ messages, currentInput, currentOutput }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, currentInput, currentOutput]);

  const renderMessage = (role: 'user' | 'model', text: string, index: string | number) => (
    <div key={index} className={`flex ${role === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn`}>
      <div className={`max-w-[85%] p-3 rounded-lg text-sm shadow-md ${
        role === 'user' 
          ? 'bg-bank-700 text-white rounded-br-none border border-bank-600' 
          : 'bg-bank-accent/10 text-blue-100 border border-bank-accent/20 rounded-bl-none'
      }`}>
        <div className={`text-[10px] uppercase tracking-wider mb-1 font-bold ${
          role === 'user' ? 'text-gray-400 text-right' : 'text-bank-accent text-left'
        }`}>
          {role === 'user' ? 'YOU' : 'CORTEX-X'}
        </div>
        <div className="whitespace-pre-wrap leading-relaxed">
          {text}
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-bank-800 border border-bank-700 rounded-lg p-6 h-full flex flex-col shadow-xl relative overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-4 border-b border-bank-700 shrink-0 z-10 bg-bank-800">
        <h2 className="text-bank-accent font-bold text-lg flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
          LIVE TRANSCRIPT
        </h2>
        <div className="flex items-center gap-2">
           <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
           <span className="text-xs text-gray-500 font-mono">REC</span>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-2 relative z-0">
        {messages.length === 0 && !currentInput && !currentOutput && (
           <div className="h-full flex flex-col items-center justify-center text-gray-600 italic opacity-50">
             <p>Waiting for connection...</p>
           </div>
        )}
        
        {messages.map((msg, idx) => renderMessage(msg.role, msg.text, idx))}
        
        {/* Real-time streaming messages */}
        {currentInput && renderMessage('user', currentInput, 'streaming-input')}
        {currentOutput && renderMessage('model', currentOutput, 'streaming-output')}
        
        <div ref={bottomRef} />
      </div>

       {/* Decorative gradient at bottom to fade text */}
       <div className="absolute bottom-0 left-0 w-full h-8 bg-gradient-to-t from-bank-800 to-transparent pointer-events-none" />
    </div>
  );
};