import React, { useEffect, useRef } from 'react';

interface Props {
  isActive: boolean;
  barColor?: string;
}

export const AudioVisualizer: React.FC<Props> = ({ isActive, barColor = '#3b82f6' }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;

    const render = () => {
      time += 0.05;
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      
      ctx.clearRect(0, 0, width, height);

      // Draw Cortex Ring
      ctx.beginPath();
      ctx.strokeStyle = isActive ? barColor : '#1f2937';
      ctx.lineWidth = 2;
      const radius = 60;
      
      // Dynamic bars
      const bars = 40;
      for (let i = 0; i < bars; i++) {
        const angle = (i / bars) * Math.PI * 2;
        // Simulate frequency data with sine waves if active
        const intensity = isActive ? (Math.sin(time * 2 + i) + Math.cos(time * 3 + i * 2)) * 0.5 + 0.5 : 0.1;
        const barHeight = isActive ? 10 + intensity * 30 : 5;
        
        const x1 = centerX + Math.cos(angle) * radius;
        const y1 = centerY + Math.sin(angle) * radius;
        const x2 = centerX + Math.cos(angle) * (radius + barHeight);
        const y2 = centerY + Math.sin(angle) * (radius + barHeight);

        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
      }
      ctx.stroke();

      // Inner glow
      if (isActive) {
        const gradient = ctx.createRadialGradient(centerX, centerY, 10, centerX, centerY, radius);
        gradient.addColorStop(0, `${barColor}00`);
        gradient.addColorStop(1, `${barColor}33`);
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius + 10, 0, Math.PI * 2);
        ctx.fill();
      }

      animationRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isActive, barColor]);

  return (
    <canvas 
      ref={canvasRef} 
      width={300} 
      height={300} 
      className="w-full h-full object-contain"
    />
  );
};
