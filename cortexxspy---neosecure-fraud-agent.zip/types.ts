export interface CaseData {
  userName: string;
  securityIdentifier: string;
  cardEnding: string;
  amount: string;
  merchant: string;
  location: string;
  transactionTime: string;
  transactionCategory: string;
  transactionSource: string;
  securityQuestion: string;
  securityAnswer: string;
  status: 'pending_review' | 'verification_failed' | 'confirmed_safe' | 'confirmed_fraud' | 'pending_call';
  outcomeNote: string;
}

export interface AudioVisualizerProps {
  isPlaying: boolean;
  volume: number;
}
